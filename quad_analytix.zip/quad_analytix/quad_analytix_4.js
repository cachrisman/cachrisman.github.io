// Using whatever frameworks you prefer, write a JavaScript snippet which loads data asynchronously in parallel from two web services ( http://service1.com/ and http://service2.com/ ). Only when both data sets are returned, display the data sets (using console.log()).

function load_data(url) {
  return new Promise((resolve, reject) => {
    var request = new XMLHttpRequest();
    request.open('GET', url);
    request.onload = function() {
      if (request.status === 200)
        resolve(request.response);
      else
        reject(Error(request.statusText));
    };
    request.onerror = function() {
      reject(Error('There was an error.'));
    };
    request.send();
  });
}

var service1 = load_data('http://service1.com/');
var service2 = load_data('http://service2.com/');

Promise.all([service1, service2]).then(values => {
  console.log(values);
}, reason => {
  console.log(reason);
});
