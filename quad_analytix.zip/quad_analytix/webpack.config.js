var webpack = require('webpack');

var config = {
  entry: __dirname + '/quad_analytix_1.jsx',
  output: {
    path: __dirname,
    filename: 'quad_analytix_1.js'
  },
  module: {
    loaders: [{
      include: __dirname,
      loader: 'babel',
    }]
  }
};

module.exports = config;

