import React from 'react';
import ReactDOM from 'react-dom';

function ListItem(props) {
  return (
      <li style={{background: (props.selected ? 'silver' : ''),
        display: (props.openview ? '' : (props.selected ? '' : 'none'))}}
        onClick={() => props.onClick()}>
      {props.name}
    </li>
  );
}

ListItem.propTypes = {
  selected: React.PropTypes.bool,
  openview: React.PropTypes.bool,
  name: React.PropTypes.string,
  onClick: React.PropTypes.func,
};

class SelectList extends React.Component {
  constructor() {
    super();
    this.state = {
      items: [{
        name:'Instagram',
        selected: false
      }, {
        name:'WhatsApp',
        selected: false
      }, {
        name:'Oculus',
        selected: false
      }],
      openview: true
    };
  }
  handleClick(i) {
    const items = this.state.items.slice();
    items[i].selected = !items[i].selected;
    this.setState({items: items});
  }
  changeView(view){
    this.setState({openview:view});
  }
  clear(state){
    const items = this.state.items.slice();
    items.forEach((i) => {i.selected = !state;});
    this.setState({items: items});
  }
  render() {
    return (
      <div className='select-list'>
        <h1>Select List for {this.props.name}</h1>
        <div id='buttons'>
          <div id='view-state'>
            View state:
            <span style={{background: (this.state.openview ? 'green' : '')}}
                  onClick={() => this.changeView(true)}>
              Open
            </span>
            <span style={{background: (!this.state.openview ? 'green' : '')}}
                  onClick={() => this.changeView(false)}>
              Closed
            </span>
          </div>
          <div id='options'>
            <span onClick={() => this.clear(true)}>
              Clear
            </span>
            <span style={{display: (this.state.openview ? '' : 'none')}}
                  onClick={() => this.clear(false)}>
              Select All
            </span>
          </div>
        </div>
        <ul>
          {this.state.items.map((item, i) =>
            <ListItem
              key = {i}
              name = {item.name}
              selected = {item.selected}
              openview = {this.state.openview}
              onClick = {() => this.handleClick(i)}
            />
          )}
        </ul>
      </div>
    );
  }
}

SelectList.propTypes = {
  name: React.PropTypes.string,
};

ReactDOM.render(
  <SelectList name='charlie'/>,
  document.getElementById('container')
);
