var value = (typeof obj1 !== 'undefined' ? (typeof obj1.obj2 !== 'undefined' ? obj1.obj2.obj3 : undefined) : undefined)

