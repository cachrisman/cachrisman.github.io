var data = [
  { name: 'California', area: '163,696 sq mi', population: 38332521 },
  { name: 'oregon', area: '98,381 sq mi', population: 3899353 },
  { name: 'Colorado', area: '163,696 sq mi', population: 38332521 },
  { name: 'washington', area: '71,300 sq mi', population: 6971406 },
  { name: 'Alaska', area: '663,268 sq mi', population: 735132 },
];

function compare(a, b) {
  var a_area = parseInt(a.area.replace(/\D*/g, ''));
  var a_name = a.name.toUpperCase();
  var b_area = parseInt(b.area.replace(/\D*/g, ''));
  var b_name = b.name.toUpperCase();
  if (a_area === b_area) {
    if (a_name < b_name) {
      return -1;
    }
    if (a_name > b_name) {
      return 1;
    }
    return 0;
  }
  return b_area - a_area;
}

function roundToIndex(x, index) {
  var digits = x.toString().length;
  var significant_digits = digits - index;
  var power = Math.pow(10, -significant_digits);
  return Math.round(x * power) / power;
}

function find_highest_population(data) {
  return data.reduce((acc, i) => {
    if (!acc || i.population > acc.population)
      return i;
    return acc;
  }).name;
}

function find_lowest_population(data) {
  return data.reduce((acc, i) => {
    if (!acc || i.population < acc.population)
      return i;
    else return acc;
  }).name;
}

String.prototype.padStart = function (targetLength, padString=' ') {
  const pad = new Array(targetLength).join(padString);
  return String(pad + this).slice(-targetLength);
};

String.prototype.padEnd = function (targetLength, padString=' ') {
  const pad = new Array(targetLength).join(padString);
  return String(this + pad).slice(0,targetLength);
};

// Answer 2-1
data.sort(compare);

// Answer 2-2
data.forEach((i) => {
  i.rounded_population = roundToIndex(i.population, 3);
  console.log(`The population of ${i.name.padEnd(10)} to 3 significant digits is ${i.rounded_population.toLocaleString()}`);
});

// Answer 2-3
data.forEach((i) => {
  var area = parseInt(i.area.replace(/\D*/g, ''));
  i.population_density = i.population / area;
  console.log(`The population density of ${i.name.padEnd(10)} is ${i.population_density.toFixed(2).padStart(6)} people per sq mi or ${(i.population_density/2.58999).toFixed(2).padStart(5)} people per sq km}`);
});

// Answer 2-4
console.log(`The most populated state is ${find_highest_population(data)}`);
console.log(`The least populated state is ${find_lowest_population(data)}`);
